#ifndef _LAPLACE_PAR_
#define _LAPLACE_PAR_

#include<omp.h>

template<int SIZE>
inline void initialize(double a[SIZE + 2][SIZE + 2], double b[SIZE + 2][SIZE + 2])
{
	//TODO implement your solution in here
}

template<int SIZE>
inline void time_step(double a[SIZE + 2][SIZE + 2], double b[SIZE + 2][SIZE + 2], int n)
{
	//TODO implement your solution in here
}

#endif // !_LAPLACE_PAR_
