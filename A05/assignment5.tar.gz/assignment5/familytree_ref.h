#ifndef FT_REF_H
#define FT_REF_H

#include "familytree.h"

void traverse_ref(tree *node);

#endif 
