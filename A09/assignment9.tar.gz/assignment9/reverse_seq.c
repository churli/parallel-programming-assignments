#include <stdio.h>
#include <stdlib.h>
#include "helper.h"

void reverse(char *str, int strlen)
{
    reverse_str(str, strlen);
}
